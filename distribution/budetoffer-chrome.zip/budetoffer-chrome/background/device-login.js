import { isRecord } from "../shared/companion-protocol.js";
export const LOGIN_KEY = 'chairs-companion-device-login-v1';
export const LOGIN_ALARM = 'chairs-companion-device-login';
const TOKEN = /^[A-Za-z0-9_-]{43}$/u;
const USER_CODE = /^[2-9A-HJKMNP-Z]{3}-[2-9A-HJKMNP-Z]{3}$/u;
export function pairingCode(value) {
    if (typeof value !== 'string')
        return null;
    const code = value.trim();
    if (TOKEN.test(code))
        return code;
    const short = code.toUpperCase();
    if (!/^[2-9A-HJKMNP-Z]{3}-?[2-9A-HJKMNP-Z]{3}$/u.test(short))
        return null;
    const raw = short.replace('-', '');
    return `${raw.slice(0, 3)}-${raw.slice(3)}`;
}
export function validDevice(value, origins, now) {
    return !!(isRecord(value) && typeof value.origin === 'string' && origins.has(value.origin) && typeof value.accessToken === 'string' && TOKEN.test(value.accessToken)
        && typeof value.deviceId === 'string' && /^[a-zA-Z0-9_-]{1,128}$/u.test(value.deviceId)
        && typeof value.expiresAt === 'string' && Date.parse(value.expiresAt) > now);
}
export function validPendingLogin(value, origins, now) {
    return !!(isRecord(value) && typeof value.origin === 'string' && origins.has(value.origin) && typeof value.deviceCode === 'string' && TOKEN.test(value.deviceCode) && typeof value.userCode === 'string' && USER_CODE.test(value.userCode)
        && typeof value.expiresAt === 'string' && Date.parse(value.expiresAt) > now
        && typeof value.nextPollAt === 'number' && Number.isFinite(value.nextPollAt) && typeof value.intervalSeconds === 'number' && Number.isInteger(value.intervalSeconds) && value.intervalSeconds >= 5 && value.intervalSeconds <= 60);
}
export function publicPendingLogin(value) {
    const target = new URL(value.origin);
    return { userCode: value.userCode, verificationUri: `${target.origin}/#companion-connect=${value.userCode}`,
        expiresAt: value.expiresAt, phoneReachable: !['127.0.0.1', 'localhost', '[::1]'].includes(target.hostname) };
}
export async function publicLoginRequest(fetchImpl, origin, path, body) {
    const response = await fetchImpl(`${origin}/api/v1/companion/${path}`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body),
        credentials: 'omit', redirect: 'error', signal: AbortSignal.timeout(15000)
    });
    if (!response.ok)
        throw new Error(response.status === 410 ? 'login_expired' : 'device_login_unavailable');
    const value = await response.json();
    if (!isRecord(value))
        throw new Error('invalid_login_response');
    if (path === 'device-login/start' && typeof value.deviceCode === 'string' && typeof value.userCode === 'string' && typeof value.expiresAt === 'string' && typeof value.intervalSeconds === 'number')
        return { deviceCode: value.deviceCode, userCode: value.userCode, expiresAt: value.expiresAt, intervalSeconds: value.intervalSeconds };
    if (path === 'device-login/poll') {
        if (value.state === 'approved' && typeof value.deviceId === 'string' && typeof value.accessToken === 'string' && typeof value.expiresAt === 'string')
            return { state: value.state, deviceId: value.deviceId, accessToken: value.accessToken, expiresAt: value.expiresAt };
        if (value.state === 'pending' || value.state === 'expired')
            return { state: value.state };
    }
    throw new Error('invalid_login_response');
}
