// Build-controlled public document links; no credentials.
export const COMPANION_ONBOARDING = Object.freeze({"version":"2026-10-10","termsUrl":"https://my.budetoffer.ru/legal/terms","privacyUrl":"https://my.budetoffer.ru/legal/privacy"});
