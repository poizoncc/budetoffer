// Static public deployment configuration; no credentials.
export const SERVER_ORIGIN = "https://my.budetoffer.ru";
export const COMPANION_ORIGINS = Object.freeze(["https://my.budetoffer.ru"]);
