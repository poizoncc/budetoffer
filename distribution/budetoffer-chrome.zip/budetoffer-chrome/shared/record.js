/** Untrusted JSON, Chrome messages and persisted values must be narrowed first. */
export function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
export function errorMessage(error) {
    // Injected errors may come from another JavaScript realm.
    return isRecord(error) && typeof error.message === "string"
        ? error.message
        : "";
}
