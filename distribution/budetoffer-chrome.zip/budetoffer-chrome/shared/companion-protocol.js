export function isRecord(value) { return typeof value === 'object' && value !== null && !Array.isArray(value); }
export function errorMessage(error) { return isRecord(error) && typeof error.message === 'string' ? error.message : undefined; }
export function isIdentifier(value) { return typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/u.test(value); }
export function isNumericIdentifier(value) { return typeof value === 'string' && /^[1-9]\d{0,30}$/u.test(value); }
function isStringArray(value) { return Array.isArray(value) && value.every(item => typeof item === 'string'); }
function isSearchParameters(value) { return Array.isArray(value) && value.every(item => Array.isArray(item) && item.length === 2 && typeof item[0] === 'string' && typeof item[1] === 'string'); }
function isOutcomeTarget(value) {
    return isRecord(value) && ['applicationId', 'resumeId', 'claimJobId', 'historyJobId'].every(key => isIdentifier(value[key]))
        && ['vacancyId', 'resumeInternalId', 'negotiationId'].every(key => isNumericIdentifier(value[key]))
        && typeof value.expectedVersion === 'number' && Number.isSafeInteger(value.expectedVersion) && value.expectedVersion >= 0;
}
function isJsonValue(value) {
    return value === null || typeof value === 'string' || typeof value === 'boolean' || (typeof value === 'number' && Number.isFinite(value))
        || (Array.isArray(value) && value.every(isJsonValue)) || (isRecord(value) && Object.values(value).every(isJsonValue));
}
export function isCompanionJob(value) {
    if (!isRecord(value) || !isIdentifier(value.jobId) || typeof value.leaseToken !== 'string' || typeof value.payloadHash !== 'string'
        || typeof value.hhAccountKey !== 'string' || typeof value.expiresAt !== 'string' || value.protocolVersion !== 1 || !isRecord(value.payload) || value.payload.kind !== value.kind
        || (value.deviceId !== undefined && typeof value.deviceId !== 'string') || (value.origin !== undefined && typeof value.origin !== 'string')
        || (value.reconcileOriginal !== undefined && !isCheckpointValue(value.reconcileOriginal)))
        return false;
    const p = value.payload;
    switch (p.kind) {
        case 'read_profile': return isStringArray(p.includeResumeIds) && typeof p.includeProfileText === 'boolean';
        case 'read_resume_artifact': return typeof p.resumeId === 'string' && typeof p.internalId === 'string';
        case 'read_application_outcomes': return Array.isArray(p.targets) && p.targets.every(isOutcomeTarget) && typeof p.maxPages === 'number';
        case 'discover_search': return typeof p.savedSearchId === 'string' && typeof p.text === 'string' && typeof p.maxPages === 'number' && (p.searchParameters === undefined || isSearchParameters(p.searchParameters));
        case 'verify_vacancy': return typeof p.vacancyId === 'string' && typeof p.applicationId === 'string' && typeof p.expectedVersion === 'number';
        case 'reconcile_history': return typeof p.vacancyId === 'string' && typeof p.resumeId === 'string' && typeof p.originalJobId === 'string' && typeof p.applicationId === 'string';
        case 'apply_vacancy': return typeof p.vacancyId === 'string' && typeof p.resumeId === 'string' && typeof p.applicationId === 'string' && typeof p.expectedVersion === 'number' && typeof p.coverLetter === 'string' && (p.answers === undefined || (isRecord(p.answers) && Object.values(p.answers).every(isJsonValue)));
        case 'publish_resume_variant': return typeof p.applicationId === 'string' && typeof p.variantId === 'string' && typeof p.baseResumeId === 'string' && typeof p.expectedVersion === 'number';
        default: return false;
    }
}
export function parseCompanionJob(value) { if (!isCompanionJob(value))
    throw new Error('invalid_companion_job'); return value; }
export function isMutationPermit(value) { return isRecord(value) && typeof value.jobId === 'string' && typeof value.payloadHash === 'string' && typeof value.permitId === 'string' && typeof value.expiresAt === 'string'; }
function isResumeEvidence(value) { return isRecord(value) && typeof value.resumeId === 'string' && typeof value.internalId === 'string'; }
function isVacancyEvidence(value) { return isRecord(value) && typeof value.vacancyId === 'string' && typeof value.title === 'string' && typeof value.text === 'string'; }
export function isJobResult(value) {
    if (!isRecord(value))
        return false;
    switch (value.kind) {
        case 'read_profile': return Array.isArray(value.resumes) && value.resumes.every(isResumeEvidence);
        case 'verify_vacancy': return isVacancyEvidence(value);
        case 'read_resume_artifact': {
            const a = value.artifact;
            return isRecord(a) && a.kind === 'resume_artifact_readback' && typeof a.readerVersion === 'string' && typeof a.hhAccountKey === 'string' && typeof a.resumeId === 'string' && typeof a.internalId === 'string' && typeof a.headline === 'string' && typeof a.about === 'string' && isStringArray(a.keySkills);
        }
        case 'discover_search': return typeof value.savedSearchId === 'string' && typeof value.pages === 'number' && typeof value.complete === 'boolean' && Array.isArray(value.vacancies) && value.vacancies.every(row => isVacancyEvidence(row) && isRecord(row) && (row.company === null || typeof row.company === 'string'));
        case 'read_application_outcomes': return typeof value.readerVersion === 'string' && typeof value.observedAt === 'string' && typeof value.pages === 'number' && typeof value.complete === 'boolean' && Array.isArray(value.observations) && value.observations.every(row => isRecord(row) && ['negotiationId', 'vacancyId', 'resumeId', 'resumeInternalId', 'stage'].every(key => typeof row[key] === 'string'));
        case 'reconcile_history': return ['originalJobId', 'vacancyId', 'resumeId', 'resumeInternalId', 'negotiationId'].every(key => typeof value[key] === 'string') && typeof value.pages === 'number' && typeof value.complete === 'boolean';
        default: return false;
    }
}
export function isCompanionReceipt(value) {
    return isRecord(value) && ['receiptId', 'jobId', 'leaseToken', 'payloadHash'].every(key => typeof value[key] === 'string')
        && ['needs_user', 'unknown', 'confirmed', 'already_exists'].some(outcome => outcome === value.outcome)
        && isRecord(value.evidence) && typeof value.evidence.hhAccountKey === 'string' && typeof value.evidence.observedAt === 'string'
        && ['reasonCode', 'vacancyId', 'resumeId'].every(key => value.evidence && isRecord(value.evidence) && (value.evidence[key] === undefined || typeof value.evidence[key] === 'string'))
        && (value.permitId === undefined || typeof value.permitId === 'string') && (value.result === undefined || isJobResult(value.result));
}
export function isCheckpointValue(value, nested = false) {
    return isRecord(value) && ['leased', 'authorized', 'reconciling', 'receipted'].some(phase => phase === value.phase)
        && typeof value.jobId === 'string' && typeof value.leaseToken === 'string' && typeof value.payloadHash === 'string'
        && (value.hhAccountKey === undefined || typeof value.hhAccountKey === 'string')
        && (value.permitId === undefined || typeof value.permitId === 'string') && (value.deviceId === undefined || typeof value.deviceId === 'string') && (value.origin === undefined || typeof value.origin === 'string')
        && (value.receipt === undefined || isCompanionReceipt(value.receipt))
        && (value.reconcileOriginal === undefined || (!nested && isCheckpointValue(value.reconcileOriginal, true)));
}
