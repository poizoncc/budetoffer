/** Packaged read-only projection of the existing Local HH outcomes contract.
 * No list placement, missing row, or initial submission state implies rejection.
 * Serialized into the isolated page: all runtime helpers must stay local.
 */
export function readApplicationOutcomesPage(request, documentRef = globalThis.document, locationHref = globalThis.location?.href) {
    function fail(code) { throw new Error(code); }
    function record(value) {
        return value !== null && typeof value === 'object' && !Array.isArray(value);
    }
    function numeric(value) {
        return (typeof value === 'number' && Number.isSafeInteger(value) && value > 0)
            || (typeof value === 'string' && /^[1-9]\d{0,30}$/u.test(value)) ? String(value) : null;
    }
    const url = new URL(locationHref);
    if (url.origin !== 'https://hh.ru' || url.username || url.password || url.hash || url.pathname !== '/applicant/negotiations' || !['active', 'archived', 'deleted'].includes(request.filter) || !Number.isInteger(request.page) || request.page < 0 || request.page >= 120 || url.search !== `?filter=${request.filter}&page=${request.page}`)
        fail('history_target_mismatch');
    if (!Array.isArray(request.targets) || !request.targets.length || request.targets.length > 20)
        fail('invalid_read_payload');
    const raw = documentRef.querySelector('template#HH-Lux-InitialState')?.innerHTML;
    if (!raw || raw.length > 4_000_000)
        fail('unsupported_history_page');
    let state;
    try {
        state = JSON.parse(raw);
    }
    catch {
        fail('unsupported_history_page');
    }
    if (!record(state))
        fail('account_identity_unverified');
    const data = state.applicantNegotiations;
    const session = record(state.session) ? state.session : null;
    if (state.userType !== 'applicant' || !state.account || !state.hhidAccount || session?.isFallback !== false || session?.securityCheckFailed !== false || session?.isMultiAccount !== false || session?.hasExtraAccounts !== false)
        fail('account_identity_unverified');
    if (!record(data) || !Array.isArray(data.topicList) || data.topicList.length > 1_000 || data.filterInUse !== request.filter)
        fail('unsupported_history_page');
    const owner = request.hhAccountKey?.match(/^hh-applicant-([1-9]\d{0,30})$/u)?.[1];
    if (!owner || (state.userId !== undefined && state.userId !== owner) || data.topicList.some((row) => !record(row) || !Number.isSafeInteger(row.applicantUserId) || String(row.applicantUserId) !== owner) || (!data.topicList.length && state.userId !== owner))
        fail('account_identity_unverified');
    const pageCount = Number(data.pageCount);
    const next = record(data.paging) && record(data.paging.next) ? data.paging.next : null;
    if (!Number.isInteger(pageCount) || pageCount < 0 || pageCount > 10_000 || typeof next?.disabled !== 'boolean')
        fail('incomplete_history_page');
    const observations = [];
    for (const row of data.topicList) {
        if (!record(row))
            fail('history_identity_missing');
        const negotiationId = numeric(row.id);
        const vacancyId = numeric(row.vacancyId);
        const resumeInternalId = numeric(row.resumeId);
        if (!negotiationId || !vacancyId || !resumeInternalId)
            fail('history_identity_missing');
        const target = request.targets.find(item => item.negotiationId === negotiationId);
        if (!target)
            continue;
        if (target.vacancyId !== vacancyId || target.resumeInternalId !== resumeInternalId)
            fail('history_identity_missing');
        let stage = 'unknown';
        // Require explicit not-applicant-declined evidence, not truthiness.
        if (row.declinedByApplicant === false) {
            if (row.lastState === 'RESPONSE' && row.viewedByOpponent === true)
                stage = 'viewed';
            else if (row.lastState === 'INVITATION')
                stage = 'invited';
            else if (row.lastState === 'DISCARD')
                stage = 'rejected';
        }
        observations.push({ negotiationId, vacancyId, resumeId: target.resumeId, resumeInternalId, stage });
    }
    return { observations, pageCount, hasNext: !next.disabled, filter: request.filter };
}
